1. install anaconda
2. In anaconda prompt 
	-->pip install flask_debug

For run the project:
1. copy the project folder path 
	like:E:\Tharun\Flask\Recommend_Review_Analysis
2. open anaconda prompt
	i) -->cd E:\Tharun\Flask\Recommend_Review_Analysis
	ii) Once the anaconda prompt change the dir to our project folder
	iii) -->python app.py
	iv) go to the browser type: localhost:5000
	v) then select Prodect submit.